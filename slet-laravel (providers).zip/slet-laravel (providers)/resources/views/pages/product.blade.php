

@extends('layouts/'.$template)


@section('content')
    <p>This is my body content.</p>
@endsection

@section('sidebar')
    <p>Здесь Олег ставит свои баннеры</p>
@endsection

