




<?php $__env->startSection('content'); ?>
    <p>This is my body content.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    <p>Здесь Олег ставит свои баннеры</p>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/'.$template, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web\htdocs\lara\resources\views/pages/contacts.blade.php ENDPATH**/ ?>