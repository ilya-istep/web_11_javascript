главная страница


<h3><?php echo e($data); ?></h3>


<?php if($flag): ?>
    <p><?php echo e($text); ?></p>
<?php endif; ?>


<?php if(count($users) > 0): ?>
    <ul>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($user); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?><?php /**PATH D:\web\htdocs\lara\resources\views/pages/welcome.blade.php ENDPATH**/ ?>