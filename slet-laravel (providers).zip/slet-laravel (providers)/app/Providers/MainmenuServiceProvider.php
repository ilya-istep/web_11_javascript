<?php 

	namespace App\Providers;

	use Illuminate\Support\Facades\View;
	use Illuminate\Support\ServiceProvider;

	class MainmenuServiceProvider extends ServiceProvider{

		public function boot()
	    {
	        View::composer('layouts/default', function($view){

	            $view->with('mainMenu', view('providers.mainmenu'));
	        });
	    }
	}