главная страница
<?php echo e($data); ?><?php /**PATH C:\OpenServer\domains\lara\resources\views/welcome.blade.php ENDPATH**/ ?>