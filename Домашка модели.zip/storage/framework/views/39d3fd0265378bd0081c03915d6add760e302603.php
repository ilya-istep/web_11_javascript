главная страница



<?php /**PATH C:\OpenServer\domains\lara\resources\views/pages/welcome.blade.php ENDPATH**/ ?>