<?php $__env->startSection('content'); ?>
    <p>This is my body main content.</p>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout.'.$template, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\lara\resources\views/pages/index.blade.php ENDPATH**/ ?>