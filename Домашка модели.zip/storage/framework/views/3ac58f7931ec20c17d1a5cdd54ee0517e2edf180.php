

<?php $__env->startSection('content'); ?>
    <p>This is my body contacts content.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\lara\resources\views/pages/contacts.blade.php ENDPATH**/ ?>