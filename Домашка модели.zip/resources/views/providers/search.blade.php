<div class="header-action-btn header-action-btn-search d-none d-md-flex">
    <div class="action-execute visible-execute">
        <a class="action-search-open" href="javascript:void(0)"><i class="icon-magnifier icons"></i></a>
        <a class="action-search-close" href="javascript:void(0)"><i class="ti-close"></i></a>
    </div>
    <!-- Search Form and Button Start -->
    <form class="header-search-form visible-execute" action="#">
        <input type="text" class="header-search-input" placeholder="Search Our Store">
        <button class="header-search-button"><i class="icon-magnifier icons"></i></button>
    </form>
    <!-- Search Form and Button End -->
</div>